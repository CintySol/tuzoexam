package com.example.login2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class registro extends AppCompatActivity implements View.OnClickListener {
    EditText nom,dir,us,pas;
    Button reg, can;
    daoUsuario dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        nom=(EditText)findViewById(R.id.nom);
        dir=(EditText)findViewById(R.id.dir);
        us=(EditText)findViewById(R.id.user2);
        pas=(EditText)findViewById(R.id.pas);
        reg=(Button)findViewById(R.id.reg);
        can=(Button)findViewById(R.id.can);
        reg.setOnClickListener(this);
        can.setOnClickListener(this);
        dao=new daoUsuario(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.reg:
                Usuario u = new Usuario();
                u.setNombre(nom.getText().toString());
                u.setDireccion(dir.getText().toString());
                u.setUsuario(us.getText().toString());
                u.setPassword(pas.getText().toString());
                if(!u.isNull()){
                    Toast.makeText(this, "error, campos vacios",Toast.LENGTH_LONG).show();

                }else if(dao.insertUsuario(u)){
                    Toast.makeText(this, "Datos registrados correctamente",Toast.LENGTH_LONG).show();
                    Intent i = new Intent(registro.this, MainActivity.class);
                    startActivity(i);
                    finish();

                }else{
                    Toast.makeText(this, "usuario ya registrado",Toast.LENGTH_LONG).show();
                }

                break;
            case R.id.can:
                Intent i2 = new Intent(registro.this, MainActivity.class);
                startActivity(i2);
                finish();

                break;

        }

    }
}