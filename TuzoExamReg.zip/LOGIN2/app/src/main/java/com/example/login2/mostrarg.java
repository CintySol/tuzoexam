package com.example.login2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class mostrarg extends AppCompatActivity {

    private TextView tv3;
    private ListView lv1;

    private String[] Pregunta={"Area del cuadrado","Area del circulo","Area del triangulo",
            "Area del trapecio","Area del hexagono","Area del rectangulo"};


    private String[] Respuesta={"lado x lado","radio X radio X 3,14","base x altura sobre 2",
            "suma de las bases por la altura, y dividido por dos","perímetro por la apotema dividido por dos",
            "base x altura"};

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrarg);

        tv3=(TextView) findViewById(R.id.tv3);
        lv1=(ListView) findViewById(R.id.lv1);


        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,Pregunta);

        lv1.setAdapter(adapter);

        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                tv3.setText("Respuesta:"+lv1.getItemIdAtPosition(position)+"  es:" + Respuesta [position]);
            }
        });

    }
}