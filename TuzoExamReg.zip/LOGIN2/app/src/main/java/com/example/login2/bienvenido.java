package com.example.login2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class bienvenido extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bienvenido);
        TextView button=findViewById(R.id.button);
        button.setOnClickListener(v -> startActivity(new Intent(bienvenido.this,crearguia.class)));
    }
    public void crearguia (View view){
        Intent button = new Intent(this,crearguia.class);
        startActivity(button);
    }
}