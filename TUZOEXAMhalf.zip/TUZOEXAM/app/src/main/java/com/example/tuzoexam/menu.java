package com.example.tuzoexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        //boton para dirigir a crear guía
        TextView button2=findViewById(R.id.button2);
        button2.setOnClickListener(v -> startActivity(new Intent(menu.this,perfil.class)));
        TextView btnlogin=findViewById(R.id.button);
        btnlogin.setOnClickListener(v -> startActivity(new Intent(menu.this,crearguia.class)));

    }
}

