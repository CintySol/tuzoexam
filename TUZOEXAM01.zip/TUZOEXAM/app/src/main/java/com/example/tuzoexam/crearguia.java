package com.example.tuzoexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class crearguia extends AppCompatActivity {
    private EditText pregunta, respuesta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crearguia);
        pregunta = (EditText) findViewById(R.id.editTextpregunta);

        respuesta = (EditText) findViewById(R.id.editTextrespuesta);
    }


    public void ingresar (View view) {
        String ipregunta =pregunta.getText().toString();
        String irespuesta =respuesta.getText().toString();
BasedeDatos basedeDatos= new BasedeDatos(this,"DATOS",null,1);
        SQLiteDatabase db=basedeDatos.getWritableDatabase();
        if(db!=null){
            ContentValues nuevapregunta= new ContentValues();
            nuevapregunta.put("pregunta", String.valueOf(pregunta));
            nuevapregunta.put("respuesta", String.valueOf(respuesta));
            db.insert("Guia",null,nuevapregunta);
            Toast.makeText(this,"Se ha guardado", Toast.LENGTH_SHORT).show();
        }
    }
}