package com.example.tuzoexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class ReContra extends AppCompatActivity {
        @Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_re_contra);
}
        public void salir (View view){
            Intent forgotPassword = new Intent(this,MainActivity.class);
            startActivity(forgotPassword);
        }
        public void recuperar (View view){
            Toast.makeText(this, "Contraseña enviada a tu correo",
                    Toast.LENGTH_SHORT).show();
        }
}