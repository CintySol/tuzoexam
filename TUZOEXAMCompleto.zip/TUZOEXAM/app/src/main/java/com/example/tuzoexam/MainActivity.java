package com.example.tuzoexam;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private EditText user,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//boton para dirigir al menu
        TextView btn = findViewById(R.id.btnlogin);

        //EditText username = (EditText) findViewById(R.id.inputEmail)
        pass = (EditText) findViewById(R.id.editTextTextPassword);

user=(EditText) findViewById(R.id.inputEmail);


    }

    public void login(View view) {

        String username=user.getText().toString();
String password=pass.getText().toString();
System.out.println("user"+username+ "password"+password);
        if (username.equals("196010031") && password.equals("tesoem")){
            Intent login = new Intent(view.getContext(), menu.class);
            startActivity(login);
            Toast.makeText(MainActivity.this,"BIENVENIDO AMIGO TUZO", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(MainActivity.this,"MATRICULA O CONTRASEÑA INCORRECTA VERIFICA PORFAVOR", Toast.LENGTH_SHORT).show();
        }


    }
    public void Olvide (View view){
        Intent forgotPassword = new Intent(this,ReContra.class);
        startActivity(forgotPassword);
    }
    public void Registrar (View view){
        Intent textViewSignUp = new Intent(this,Registro.class);
        startActivity(textViewSignUp);
    }
}